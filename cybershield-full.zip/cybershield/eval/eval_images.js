#!/usr/bin/env node
// Evaluates the IMAGE scanner on a labelled dataset, using the same prompt and model settings as the app.
//
//   node eval/eval_images.js path/to/dataset [--limit 100] [--seed 7] [--concurrency 3] [--out file.csv]
//
// Dataset layout (label 0 = real photo, label 1 = AI-generated / manipulated):
//   dataset/real/*.jpg|png|webp|gif
//   dataset/fake/*.jpg|png|webp|gif
//
// --limit N   uses N images per class, chosen with a seeded shuffle (reproducible).
// Needs ANTHROPIC_API_KEY (from .env or the environment). Each image is one API call and uses credits.
try { require('dotenv').config({ path: require('path').join(__dirname, '..', '.env') }); } catch {}
const fs = require('fs');
const path = require('path');
const { IMAGE_PROMPT } = require('../prompts');
const { evaluate } = require('./metrics');

const args = process.argv.slice(2);
const opt = (n, d) => { const i = args.indexOf('--' + n); return i >= 0 ? args[i + 1] : d; };
const dir = args.find((a, i) => !a.startsWith('--') && !(i > 0 && args[i - 1].startsWith('--')));
const LIMIT = Number(opt('limit', 0)), SEED = Number(opt('seed', 7)), CONC = Number(opt('concurrency', 3));
const MODEL = process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-6';
const OUT = opt('out', path.join(__dirname, 'predictions_images.csv'));
const KEY = process.env.ANTHROPIC_API_KEY;
const TYPES = { '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png', '.webp': 'image/webp', '.gif': 'image/gif' };

if (!dir || !KEY) {
  console.log('Usage: node eval/eval_images.js dataset_dir [--limit 100] [--seed 7] [--concurrency 3] [--out file.csv]');
  console.log('Needs ANTHROPIC_API_KEY in .env or the environment, and dataset_dir/real + dataset_dir/fake.');
  process.exit(1);
}

function rng(seed) { // mulberry32: small seeded PRNG so the sample is reproducible
  let a = seed >>> 0;
  return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}
function pick(sub, label) {
  const d = path.join(dir, sub);
  if (!fs.existsSync(d)) { console.error(`Missing folder: ${d}`); process.exit(1); }
  let files = fs.readdirSync(d).filter(f => TYPES[path.extname(f).toLowerCase()]).sort().map(f => path.join(d, f));
  const r = rng(SEED + label);
  for (let i = files.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [files[i], files[j]] = [files[j], files[i]]; }
  if (LIMIT) files = files.slice(0, LIMIT);
  return files.map(file => ({ file, label }));
}

const sleep = ms => new Promise(r => setTimeout(r, ms));
function extractJson(raw) {
  const c = raw.replace(/```(?:json)?/gi, '');
  return JSON.parse(c.slice(c.indexOf('{'), c.lastIndexOf('}') + 1));
}

async function scan(item) {
  const buf = fs.readFileSync(item.file);
  if (buf.length > 4.5 * 1024 * 1024) return { ...item, status: 'skipped_too_large' };
  const body = JSON.stringify({
    model: MODEL, max_tokens: 800, temperature: 0, system: IMAGE_PROMPT,
    messages: [{ role: 'user', content: [
      { type: 'image', source: { type: 'base64', media_type: TYPES[path.extname(item.file).toLowerCase()], data: buf.toString('base64') } },
      { type: 'text', text: 'Analyze this image as instructed.' }
    ] }]
  });
  for (let attempt = 0; attempt < 4; attempt++) {
    let res;
    try {
      res = await fetch('https://api.anthropic.com/v1/messages', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-api-key': KEY, 'anthropic-version': '2023-06-01' }, body });
    } catch { await sleep(1500 * 2 ** attempt); continue; }
    if (res.ok) {
      try {
        const data = await res.json();
        const j = extractJson((data.content || []).map(b => b.text || '').join(''));
        const score = Math.max(0, Math.min(100, Math.round(Number(j.score))));
        if (!Number.isFinite(score)) throw new Error('no score');
        return { ...item, status: 'ok', score, confidence: ['low', 'medium', 'high'].includes(j.confidence) ? j.confidence : 'medium' };
      } catch { return { ...item, status: 'unparseable' }; }
    }
    if ([429, 500, 502, 503, 529].includes(res.status)) { await sleep(1500 * 2 ** attempt); continue; }
    return { ...item, status: 'api_' + res.status };
  }
  return { ...item, status: 'api_failed' };
}

(async () => {
  const items = [...pick('real', 0), ...pick('fake', 1)];
  console.log(`Scanning ${items.length} images with ${MODEL} (seed ${SEED}, ${CONC} at a time)...`);
  const results = new Array(items.length);
  let next = 0, done = 0;
  await Promise.all(Array.from({ length: CONC }, async () => {
    while (next < items.length) {
      const i = next++;
      results[i] = await scan(items[i]);
      if (++done % 10 === 0 || done === items.length) console.log(`  ${done}/${items.length}`);
    }
  }));

  const ok = results.filter(r => r.status === 'ok');
  const bad = results.filter(r => r.status !== 'ok');
  fs.writeFileSync(OUT, 'label,score,confidence,file\n' + ok.map(r => `${r.label},${r.score},${r.confidence},${path.basename(r.file).replace(/,/g, '_')}`).join('\n') + '\n');

  const r2 = v => (typeof v === 'number' ? Math.round(v * 1000) / 1000 : v);
  const real = ok.filter(r => r.label === 0), fake = ok.filter(r => r.label === 1);
  console.log(`\nEvaluated ${ok.length} (real ${real.length}, fake ${fake.length}). Not evaluated: ${bad.length}` + (bad.length ? ' (' + [...new Set(bad.map(b => b.status))].join(', ') + ')' : ''));
  const summary = {};
  for (const [name, th] of [['threshold 50', 50], ['threshold 65 (app: "Likely AI-generated or edited")', 65]]) {
    const m = evaluate(ok, th);
    summary[name] = m;
    console.log(`\n=== ${name} ===`);
    console.log(`TP=${m.tp} FP=${m.fp} TN=${m.tn} FN=${m.fn}`);
    console.log(`Accuracy ${r2(m.accuracy)} (95% CI ${m.accuracyCI95.map(r2).join(' - ')})  Precision ${r2(m.precision)}  Recall ${r2(m.recall)}  F1 ${r2(m.f1)}  AUC ${r2(m.auc)}`);
  }
  const inc = ok.filter(r => r.score > 35 && r.score < 65).length;
  const mean = a => (a.length ? a.reduce((s, r) => s + r.score, 0) / a.length : NaN);
  console.log(`\nInconclusive band (36-64): ${inc}/${ok.length} = ${r2(inc / (ok.length || 1))}`);
  console.log(`Mean score: real ${r2(mean(real))}, fake ${r2(mean(fake))}`);
  fs.writeFileSync(OUT.replace(/\.csv$/, '.json'), JSON.stringify({ model: MODEL, seed: SEED, limit: LIMIT, date: new Date().toISOString(), evaluated: ok.length, notEvaluated: bad.length, inconclusive: inc, summary }, null, 2));
  console.log(`\nWrote ${OUT} and its .json summary.`);
})();
