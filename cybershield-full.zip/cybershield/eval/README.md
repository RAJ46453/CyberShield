# Evaluation kit

Everything here measures the project as it actually exists. Nothing is simulated.

## 1. Link checker (rules only)
    node eval/eval_links.js                 # runs on eval/links_sample.csv (n=80, author-written)
    node eval/eval_links.js your_links.csv  # CSV columns: label,url   (1 = phishing, 0 = benign)

Reports TP/FP/TN/FN, accuracy with a 95% Wilson interval, precision, recall, F1 and AUC at two
operating points (score >= 20 "Suspicious or worse", score >= 45 "High risk only"), then lists every
miss and false alarm.

`links_sample.csv` is a small hand-written set (40 benign, 40 phishing-style, including hard cases
on both sides). It is NOT an independent benchmark. For a paper, rebuild it from public feeds:
phishing URLs from PhishTank or OpenPhish, benign URLs from the Tranco top-sites list, with a
fixed random seed, and report the sources and collection date.

## 2. Any other module (image, document, video)
Run your detector on a labelled dataset, then write one CSV row per item:

    label,score
    1,87
    0,12

(label 1 = fake / AI-generated / malicious, 0 = real / human / benign; score 0-100.) Then:

    node eval/metrics.js predictions.csv 50     # second argument = decision threshold

Suggested protocol: hold out a test set you never looked at while writing prompts, fix the
threshold in advance (or choose it on a separate validation split), report n and the dataset
source, and give confidence intervals. Use human vs AI text corpora for documents, and real vs
generated photo sets for images. The video tab in this build is a placeholder, so there is no
video result to report unless you add a real video model.

## Known limits of the link checker (from the sample run)
Rules cannot see look-alike typos (paypa1.com), clean-looking new domains, shorteners alone, or
abuse of trusted hosts (sites.google.com, forms.gle). One legitimate Microsoft host
(outlook.office365.com) is flagged because both "outlook" and "office365" are on the brand list.
Fixing that on the same sample would be tuning on the test set, so re-evaluate on fresh data after
any rule change.

## 3. Image scanner
    node eval/eval_images.js path/to/dataset --limit 100 --seed 7

Folders: `dataset/real/` (label 0) and `dataset/fake/` (label 1). It sends each image to the same
model with the same prompt as the app (the prompt lives in `prompts.js`, shared with the server),
writes `eval/predictions_images.csv` plus a `.json` summary, and prints accuracy (with 95% CI),
precision, recall, F1 and AUC at threshold 50 and at 65 (the app's "Likely AI-generated or edited"
cutoff), the share of results in the inconclusive band (36-64), and mean scores per class.
Each image is one API call and uses credits; start with 50-100 per class. Images over 4.5 MB are
skipped and counted as "not evaluated". Report that count.

Dataset ideas (check each licence and citation requirement): GenImage, ArtiFact, "140k Real and
Fake Faces" (Kaggle), or your own set: real photos from a public collection (e.g. COCO or Open
Images) against images you generate yourself with documented tools and prompts. Prefer images of at
least 256 px: very small images such as CIFAKE's 32x32 give a visual model little to inspect.
Match real and fake on format, size and compression, otherwise the test measures those instead.
Report the model name, run date, dataset, seed and n. Compressed, resized or screenshot images are
harder, so state what pre-processing, if any, was applied.
