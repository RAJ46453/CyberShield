// Metrics for a binary detector. positive class (1) = malicious / AI-generated / fake.
// Input: array of { label: 0|1, score: 0-100 }. Predicts positive when score >= threshold.
function confusion(rows, threshold) {
  let tp = 0, fp = 0, tn = 0, fn = 0;
  for (const r of rows) {
    const pred = r.score >= threshold ? 1 : 0;
    if (pred && r.label) tp++; else if (pred && !r.label) fp++; else if (!pred && !r.label) tn++; else fn++;
  }
  return { tp, fp, tn, fn };
}

// AUC via the rank-sum (Mann-Whitney) formulation, with average ranks for ties
function auc(rows) {
  const pos = rows.filter(r => r.label === 1).length, neg = rows.length - pos;
  if (!pos || !neg) return NaN;
  const sorted = [...rows].sort((a, b) => a.score - b.score);
  let rankSumPos = 0;
  for (let i = 0; i < sorted.length;) {
    let j = i;
    while (j < sorted.length && sorted[j].score === sorted[i].score) j++;
    const avgRank = (i + 1 + j) / 2;
    for (let k = i; k < j; k++) if (sorted[k].label === 1) rankSumPos += avgRank;
    i = j;
  }
  return (rankSumPos - pos * (pos + 1) / 2) / (pos * neg);
}

// 95% Wilson interval for a proportion
function wilson(k, n, z = 1.96) {
  if (!n) return [NaN, NaN];
  const p = k / n, d = 1 + z * z / n;
  const c = (p + z * z / (2 * n)) / d, m = (z * Math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))) / d;
  return [c - m, c + m];
}

function evaluate(rows, threshold) {
  const { tp, fp, tn, fn } = confusion(rows, threshold);
  const n = rows.length, div = (a, b) => (b ? a / b : NaN);
  const precision = div(tp, tp + fp), recall = div(tp, tp + fn);
  return {
    threshold, n, tp, fp, tn, fn,
    accuracy: div(tp + tn, n), accuracyCI95: wilson(tp + tn, n),
    precision, recall, f1: div(2 * precision * recall, precision + recall),
    auc: auc(rows)
  };
}

function loadCsv(text) {
  // columns: label,score   (label 1 = malicious/AI/fake, 0 = benign/real/human)
  return text.split(/\r?\n/).slice(1).filter(Boolean).map(l => {
    const [label, score] = l.split(',');
    return { label: Number(label), score: Number(score) };
  });
}

module.exports = { evaluate, confusion, auc, wilson, loadCsv };

// CLI:  node eval/metrics.js predictions.csv [threshold]
if (require.main === module) {
  const fs = require('fs');
  const file = process.argv[2];
  if (!file) { console.log('Usage: node eval/metrics.js predictions.csv [threshold=50]   (csv columns: label,score)'); process.exit(1); }
  const th = Number(process.argv[3] || 50);
  const r = evaluate(loadCsv(fs.readFileSync(file, 'utf8')), th);
  console.log(JSON.stringify(r, (k, v) => typeof v === 'number' ? Math.round(v * 1000) / 1000 : v, 2));
}
