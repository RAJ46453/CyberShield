// Runs the rule-based link checker over a labelled CSV and prints metrics.
//   node eval/eval_links.js [eval/links_sample.csv]
// CSV columns: label,url   (1 = malicious/phishing, 0 = benign)
// Note: this measures the RULES ONLY (no AI second opinion, no Safe Browsing).
const fs = require('fs');
const path = require('path');
const { analyzeUrl } = require('../urlcheck');
const { evaluate } = require('./metrics');

const file = process.argv[2] || path.join(__dirname, 'links_sample.csv');
const rows = fs.readFileSync(file, 'utf8').split(/\r?\n/).slice(1).filter(Boolean).map(line => {
  const i = line.indexOf(',');
  const label = Number(line.slice(0, i)), url = line.slice(i + 1);
  const r = analyzeUrl(url);
  return { label, url, score: r.error ? 0 : r.score };
});

const round = v => (typeof v === 'number' ? Math.round(v * 1000) / 1000 : v);
for (const th of [20, 45]) {
  const m = evaluate(rows, th);
  console.log(`\n=== threshold >= ${th} (${th === 20 ? 'Suspicious or worse' : 'High risk only'}) ===`);
  console.log(`n=${m.n}  TP=${m.tp} FP=${m.fp} TN=${m.tn} FN=${m.fn}`);
  console.log(`Accuracy ${round(m.accuracy)}  (95% CI ${m.accuracyCI95.map(round).join(' - ')})`);
  console.log(`Precision ${round(m.precision)}  Recall ${round(m.recall)}  F1 ${round(m.f1)}  AUC ${round(m.auc)}`);
}
console.log('\nMissed malicious links (false negatives at >=20):');
rows.filter(r => r.label === 1 && r.score < 20).forEach(r => console.log(`  score ${String(r.score).padStart(3)}  ${r.url}`));
console.log('\nFlagged benign links (false positives at >=20):');
rows.filter(r => r.label === 0 && r.score >= 20).forEach(r => console.log(`  score ${String(r.score).padStart(3)}  ${r.url}`));
