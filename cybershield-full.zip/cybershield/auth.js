// Cybershield auth: scrypt password hashing, signed httpOnly session cookies,
// and a small JSON user store. Uses only Node built-ins.
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, 'data');
const USERS_FILE = path.join(DATA_DIR, 'users.json');
const SESSION_DAYS = 7;
const COOKIE = 'cs_session';

let SECRET = process.env.SESSION_SECRET;
if (!SECRET || SECRET.length < 32) {
  SECRET = crypto.randomBytes(32).toString('hex');
  console.warn('SESSION_SECRET missing or under 32 chars: using a temporary one. Everyone is logged out on restart. Set a long random value in .env.');
}

// ---------- user store ----------
let users = {};
try { users = JSON.parse(fs.readFileSync(USERS_FILE, 'utf8')); } catch { users = {}; }

let writeChain = Promise.resolve();
function saveUsers() {
  writeChain = writeChain.then(async () => {
    await fs.promises.mkdir(DATA_DIR, { recursive: true });
    const tmp = USERS_FILE + '.tmp';
    await fs.promises.writeFile(tmp, JSON.stringify(users, null, 2), { mode: 0o600 });
    await fs.promises.rename(tmp, USERS_FILE);
  });
  return writeChain;
}

// ---------- passwords ----------
const hashPw = (pw, salt) => new Promise((res, rej) =>
  crypto.scrypt(pw, salt, 64, { N: 16384, r: 8, p: 1 }, (e, k) => (e ? rej(e) : res(k))));

async function makeHash(pw) {
  const salt = crypto.randomBytes(16);
  return salt.toString('hex') + ':' + (await hashPw(pw, salt)).toString('hex');
}
async function checkHash(pw, stored) {
  const [saltHex, hashHex] = stored.split(':');
  const expected = Buffer.from(hashHex, 'hex');
  const actual = await hashPw(pw, Buffer.from(saltHex, 'hex'));
  return expected.length === actual.length && crypto.timingSafeEqual(expected, actual);
}
let DUMMY; // used so unknown usernames cost the same time as wrong passwords
const dummyHash = async () => (DUMMY ||= await makeHash('dummy-password-for-timing'));

// ---------- validation ----------
const normUser = u => String(u || '').trim().toLowerCase();
function validate(username, password) {
  if (!/^[a-z0-9_.-]{3,32}$/.test(username)) return 'Username must be 3-32 characters: letters, numbers, dot, dash or underscore.';
  if (typeof password !== 'string' || password.length < 10) return 'Password must be at least 10 characters.';
  if (password.length > 200) return 'Password is too long.';
  if (password.toLowerCase().includes(username)) return 'Password must not contain your username.';
  return null;
}

async function register(rawUser, password) {
  const username = normUser(rawUser);
  const err = validate(username, password);
  if (err) return { error: err };
  if (users[username]) return { error: 'That username is taken.' };
  users[username] = { hash: await makeHash(password), created: new Date().toISOString() };
  await saveUsers();
  return { username };
}

async function login(rawUser, password) {
  const username = normUser(rawUser);
  const rec = users[username];
  const ok = await checkHash(String(password || '').slice(0, 200), rec ? rec.hash : await dummyHash());
  return rec && ok ? { username } : { error: 'Incorrect username or password.' };
}

// ---------- sessions ----------
const sign = s => crypto.createHmac('sha256', SECRET).update(s).digest('base64url');

function makeToken(username) {
  const body = Buffer.from(JSON.stringify({ u: username, e: Date.now() + SESSION_DAYS * 864e5 })).toString('base64url');
  return body + '.' + sign(body);
}
function readToken(token) {
  if (!token || !token.includes('.')) return null;
  const [body, sig] = token.split('.');
  const good = sign(body);
  if (sig.length !== good.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(good))) return null;
  try {
    const { u, e } = JSON.parse(Buffer.from(body, 'base64url').toString());
    return e > Date.now() && users[u] ? u : null;
  } catch { return null; }
}

function parseCookies(header) {
  const out = {};
  String(header || '').split(';').forEach(p => {
    const i = p.indexOf('=');
    if (i > 0) out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim());
  });
  return out;
}
function setSession(res, username, secure) {
  res.append('Set-Cookie', `${COOKIE}=${makeToken(username)}; Max-Age=${SESSION_DAYS * 86400}; Path=/; HttpOnly; SameSite=Lax${secure ? '; Secure' : ''}`);
}
function clearSession(res) {
  res.append('Set-Cookie', `${COOKIE}=; Max-Age=0; Path=/; HttpOnly; SameSite=Lax`);
}
function currentUser(req) { return readToken(parseCookies(req.headers.cookie)[COOKIE]); }

module.exports = { register, login, setSession, clearSession, currentUser, hasUsers: () => Object.keys(users).length > 0 };
