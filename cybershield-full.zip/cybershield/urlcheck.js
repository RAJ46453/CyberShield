// Rule-based link analysis. Looks only at the text of the link: it never visits it.
const SHORTENERS = new Set(['bit.ly', 'tinyurl.com', 't.co', 'goo.gl', 'ow.ly', 'is.gd', 'buff.ly', 'rebrand.ly', 'cutt.ly', 'tiny.cc', 'shorturl.at', 'rb.gy', 'bl.ink', 'lnkd.in']);
const BAD_TLDS = new Set(['zip', 'mov', 'xyz', 'top', 'tk', 'ml', 'ga', 'cf', 'gq', 'click', 'country', 'work', 'support', 'rest', 'icu', 'buzz', 'cyou', 'cfd', 'sbs']);
const BRANDS = ['paypal', 'google', 'microsoft', 'apple', 'amazon', 'facebook', 'instagram', 'netflix', 'whatsapp', 'paytm', 'phonepe', 'sbi', 'hdfc', 'icici', 'axis', 'dhl', 'fedex', 'irs', 'binance', 'coinbase', 'metamask', 'linkedin', 'outlook', 'office365'];
const KEYWORDS = ['login', 'signin', 'verify', 'secure', 'account', 'update', 'confirm', 'wallet', 'password', 'otp', 'kyc', 'bonus', 'prize', 'claim', 'suspend', 'unlock'];
const SECOND_LEVEL = new Set(['co', 'com', 'org', 'net', 'gov', 'ac', 'edu', 'nic']);
const REDIRECT_KEYS = ['url', 'redirect', 'redirect_uri', 'next', 'goto', 'return', 'dest', 'destination', 'continue'];

function registrable(host) {
  const p = host.split('.');
  const n = p.length;
  if (n <= 2) return host;
  if (p[n - 1].length === 2 && SECOND_LEVEL.has(p[n - 2])) return p.slice(-3).join('.');
  return p.slice(-2).join('.');
}

function analyzeUrl(input) {
  let raw = String(input || '').trim();
  if (!raw) return { error: 'Enter a link to check.' };
  if (raw.length > 2000) return { error: 'That link is too long (limit 2000 characters).' };
  if (/\s/.test(raw)) return { error: 'Links cannot contain spaces.' };

  const flags = [];
  const add = (label, weight) => flags.push({ label, weight });

  // Code-running or file links: flag immediately instead of parsing further
  const scheme = (raw.match(/^([a-z][a-z0-9+.-]*):/i) || [])[1];
  const looksLikeHostPort = /^[a-z0-9.-]+:\d+(\/|$)/i.test(raw);
  if (scheme && !looksLikeHostPort && !/^https?$/i.test(scheme)) {
    if (/^(javascript|data|vbscript|file|blob)$/i.test(scheme)) {
      return { host: '', normalized: raw.slice(0, 200), assumedScheme: false, score: 100,
        flags: [{ label: `Uses a "${scheme.toLowerCase()}:" link, which can run code or open local content instead of loading a website`, weight: 100 }] };
    }
    return { error: 'Only http and https links can be checked.' };
  }

  const assumedScheme = !/^https?:\/\//i.test(raw);
  let u;
  try { u = new URL(assumedScheme ? 'https://' + raw : raw); }
  catch { return { error: "That doesn't look like a valid link." }; }

  const host = u.hostname.toLowerCase();
  if (!host) return { error: "That doesn't look like a valid link." };
  const isIp = /^\d{1,3}(\.\d{1,3}){3}$/.test(host) || host.startsWith('[');
  const labels = host.split('.');
  const tld = labels[labels.length - 1];
  const reg = registrable(host);
  const regLabel = reg.split('.')[0];
  const path = (u.pathname + u.search).toLowerCase();

  if (!assumedScheme && u.protocol === 'http:') add('Uses plain http, so the connection is not encrypted', 10);
  if (u.username || u.password) add('Has a "name@" section before the real address, a common trick to disguise where the link goes', 30);
  if (isIp) add('Uses a raw IP address instead of a normal domain name', 25);
  if (host.includes('xn--')) add('Domain uses punycode (xn--), which can disguise look-alike characters', 25);
  if (u.port) add(`Uses an unusual port (${u.port})`, 10);
  if (!isIp) {
    if (SHORTENERS.has(host)) add('Link shortener: the real destination is hidden', 15);
    if (BAD_TLDS.has(tld)) add(`Ends in ".${tld}", an ending often seen in throwaway or abusive sites`, 15);

    const tokens = host.split(/[.-]/);
    const brand = BRANDS.find(b => tokens.includes(b));
    if (brand && regLabel !== brand) add(`Mentions "${brand}" but the real domain is ${reg}, a classic look-alike pattern`, 25);
    else if (!brand) {
      const inPath = BRANDS.find(b => path.includes(b));
      if (inPath) add(`Uses the name "${inPath}" in the path of an unrelated domain (${reg})`, 10);
    }
    if (labels.length - reg.split('.').length >= 3) add('Has an unusually long chain of subdomains', 10);
    if ((host.replace(/xn--/g, '').match(/-/g) || []).length >= 3) add('Domain contains many hyphens', 8);
    if (/\d{4,}/.test(regLabel)) add('Domain name contains a long run of digits', 5);
  }

  const hits = KEYWORDS.filter(k => host.includes(k) || path.includes(k));
  if (hits.length) add(`Contains pressure or account words (${hits.slice(0, 3).join(', ')})`, Math.min(16, hits.length * 8));
  if (/\.(exe|apk|scr|msi|bat|cmd|jar|vbs|dmg|iso)$/i.test(u.pathname)) add('Points directly at a downloadable program file', 20);
  for (const k of REDIRECT_KEYS) {
    const v = u.searchParams.get(k);
    if (v && /^https?:\/\//i.test(v)) { add('Contains another link inside it (possible redirect)', 10); break; }
  }
  if ((raw.match(/%[0-9a-f]{2}/gi) || []).length > 5) add('Heavily encoded characters in the link', 5);
  if (u.href.length > 100) add('Unusually long link', 5);

  return { host, normalized: u.href, assumedScheme, flags, score: Math.min(100, flags.reduce((s, f) => s + f.weight, 0)) };
}

// Keep the address and the names of query parameters, but not their values (tokens, emails…)
function redactUrl(normalized) {
  try {
    const u = new URL(normalized);
    const keys = [...u.searchParams.keys()];
    return u.origin.replace(/\/\/[^@/]*@/, '//') + u.pathname + (keys.length ? '?' + keys.map(k => k + '=…').join('&') : '');
  } catch { return ''; }
}

module.exports = { analyzeUrl, redactUrl };
