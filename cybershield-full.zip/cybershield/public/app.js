const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const MAX_FILE_BYTES = 15 * 1024 * 1024;
const MAX_CHARS = 20000;
const $ = id => document.getElementById(id);

if (window.pdfjsLib) {
  pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
}

// ---- session ----
fetch('/api/me').then(r => r.ok ? r.json() : Promise.reject()).then(j => { $('userName').textContent = j.user; })
  .catch(() => { location.href = '/login.html'; });
$('logout').addEventListener('click', async () => {
  try { await fetch('/api/logout', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' }); } catch {}
  location.href = '/login.html';
});

// ---- mouse-reactive grid ----
if (!reduceMotion) {
  document.addEventListener('mousemove', e => {
    const x = (e.clientX / window.innerWidth - 0.5) * 16;
    const y = (e.clientY / window.innerHeight - 0.5) * 16;
    $('gridBg').style.transform = `translate(${x}px, ${y}px)`;
  });
}
// Dropping a file outside a dropzone shouldn't navigate away from the page
['dragover', 'drop'].forEach(ev => window.addEventListener(ev, e => e.preventDefault()));

// ---- tabs ----
const segTabs = document.querySelectorAll('.seg-tab');
const pill = $('pill');
const panels = { document: $('panel-document'), image: $('panel-image'), video: $('panel-video'), link: $('panel-link') };
const statusText = $('statusText');
const resultEl = $('result');

function movePill(el) {
  pill.style.width = el.offsetWidth + 'px';
  pill.style.transform = `translateX(${el.offsetLeft - 4}px)`;
}
const activeTab = () => document.querySelector('.seg-tab.active');
window.addEventListener('load', () => movePill(activeTab()));
window.addEventListener('resize', () => movePill(activeTab()));

function selectTab(t) {
  segTabs.forEach(x => { x.classList.remove('active'); x.setAttribute('aria-selected', 'false'); x.tabIndex = -1; });
  t.classList.add('active');
  t.setAttribute('aria-selected', 'true');
  t.tabIndex = 0;
  movePill(t);
  Object.entries(panels).forEach(([key, el]) => { el.hidden = key !== t.dataset.tab; });
  resultEl.classList.remove('show');
}
segTabs.forEach((t, i) => {
  t.tabIndex = t.classList.contains('active') ? 0 : -1;
  t.addEventListener('click', () => selectTab(t));
  t.addEventListener('keydown', e => {
    if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
    const next = segTabs[(i + (e.key === 'ArrowRight' ? 1 : segTabs.length - 1)) % segTabs.length];
    selectTab(next);
    next.focus();
  });
});

// ---- generic dropzone wiring (mouse, drag-drop, keyboard) ----
function wireDropzone(zone, input, onFile) {
  zone.addEventListener('click', () => input.click());
  zone.addEventListener('keydown', e => {
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); input.click(); }
  });
  ['dragenter', 'dragover'].forEach(ev => zone.addEventListener(ev, e => { e.preventDefault(); zone.classList.add('drag'); }));
  ['dragleave', 'drop'].forEach(ev => zone.addEventListener(ev, e => { e.preventDefault(); zone.classList.remove('drag'); }));
  zone.addEventListener('drop', e => { if (e.dataTransfer.files.length) onFile(e.dataTransfer.files[0]); });
  input.addEventListener('change', e => { if (e.target.files.length) onFile(e.target.files[0]); input.value = ''; });
}

// ---- verdict tiers ----
function tierFor(score, kind) {
  if (kind === 'url') {
    if (score >= 45) return { key: 'flag', label: 'High risk: likely phishing or malicious' };
    if (score >= 20) return { key: 'mixed', label: 'Suspicious: be careful' };
    return { key: 'verified', label: 'No obvious red flags' };
  }
  const img = kind === 'image';
  if (score >= 65) return { key: 'flag', label: img ? 'Likely AI-generated or edited' : 'Likely AI-generated' };
  if (score <= 35) return { key: 'verified', label: img ? 'Likely an authentic photo' : 'Likely human-written' };
  return { key: 'mixed', label: 'Inconclusive / mixed signals' };
}

// ---- gauge + result renderer ----
const CIRC = 314;
let lastResultText = '';
let lastReport = null;

function showResult(scorePct, notes, opts = {}) {
  const { demo = false, confidence = null, truncated = false, words = null, kind = 'text', phrases = [], source = '', host = '' } = opts;
  const tier = demo ? { key: 'demo', label: 'Demo only — not a real result' } : tierFor(scorePct, kind);
  renderExcerpts(kind === 'text' ? source : '', phrases);

  const verdictEl = $('verdict');
  verdictEl.textContent = tier.label;
  verdictEl.className = 'verdict ' + tier.key;

  const gaugeFill = $('gaugeFill');
  gaugeFill.setAttribute('class', 'gauge-fill ' + tier.key);

  const meta = [];
  if (!demo && confidence) meta.push(`confidence: ${confidence}`);
  if (host) meta.push(host);
  if (words) meta.push(`${words.toLocaleString()} words`);
  if (truncated) meta.push(`only the first ${MAX_CHARS.toLocaleString()} characters were analysed`);
  $('metaLine').textContent = meta.join(' · ');

  const notesList = $('notesList');
  notesList.innerHTML = '';
  notes.forEach(n => {
    const li = document.createElement('li');
    li.textContent = n;
    notesList.appendChild(li);
  });

  lastResultText = `Cybershield: ${tier.label}${demo ? '' : ` (${scorePct}%)`}\n` +
    (meta.length ? meta.join(' · ') + '\n' : '') + notes.map(n => '- ' + n).join('\n');
  $('copyResult').hidden = demo;
  $('printBtn').hidden = demo;
  $('saveRep').hidden = demo;
  lastReport = demo ? null : {
    kind: kind === 'url' ? 'Link check' : kind === 'image' ? 'Image scan' : 'Document scan',
    label: tier.label, score: scorePct, scoreLabel: kind === 'url' ? 'risk score' : 'AI likelihood',
    meta: meta.join(' · '), notes,
    passages: $('exWrap').hidden ? '' : $('exWrap').innerText,
    time: new Date().toLocaleString()
  };
  $('copyResult').textContent = 'Copy result';

  resultEl.classList.add('show');

  // Reset ring instantly so repeat scans animate from zero
  gaugeFill.style.transition = 'none';
  gaugeFill.style.strokeDashoffset = CIRC;
  void gaugeFill.getBoundingClientRect();
  gaugeFill.style.transition = '';
  const offset = CIRC - (CIRC * scorePct / 100);
  requestAnimationFrame(() => { gaugeFill.style.strokeDashoffset = offset; });

  const gaugeNumber = $('gaugeNumber');
  gaugeNumber.textContent = demo ? '—' : '0%';
  if (!demo) {
    const duration = reduceMotion ? 0 : 800;
    const start = performance.now();
    const tick = now => {
      const p = duration === 0 ? 1 : Math.min(1, (now - start) / duration);
      gaugeNumber.textContent = Math.round(p * scorePct) + '%';
      if (p < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }
  resultEl.scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth', block: 'nearest' });
}

function renderExcerpts(body, phrases) {
  const ex = $('exWrap');
  ex.replaceChildren();
  const low = body.toLowerCase();
  const found = (Array.isArray(phrases) ? phrases : []).map(String).filter(p => p.length > 4)
    .map(p => { const i = low.indexOf(p.toLowerCase()); return i < 0 ? null : [i, p.length]; })
    .filter(Boolean).slice(0, 4);
  ex.hidden = !found.length;
  if (!found.length) return;
  const title = document.createElement('div');
  title.className = 'ex-title';
  title.textContent = 'Passages that influenced the score';
  ex.append(title);
  found.forEach(([i, l]) => {
    const d = document.createElement('div');
    const from = Math.max(0, i - 80), to = Math.min(body.length, i + l + 80);
    const m = document.createElement('mark');
    m.textContent = body.slice(i, i + l);
    d.append((from > 0 ? '…' : '') + body.slice(from, i), m, body.slice(i + l, to) + (to < body.length ? '…' : ''));
    ex.append(d);
  });
}


function buildReport(r){
  const e=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  return '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Cybershield report</title><style>'+
  'body{font:15px/1.6 system-ui,sans-serif;max-width:720px;margin:40px auto;padding:0 20px;color:#1b1626}h1{font-size:22px;margin:0}'+
  '.sub{color:#6b6283;font-size:13px;margin-bottom:24px}.v{font-size:24px;font-weight:700;margin:20px 0 4px}.s{font:600 40px ui-monospace,monospace}.s small{font:13px system-ui;color:#6b6283}'+
  '.m{color:#6b6283;font:13px ui-monospace,monospace;margin-bottom:14px}li{margin-bottom:8px}pre{white-space:pre-wrap;font:13px/1.6 ui-monospace,monospace;background:#f4f0fb;padding:12px;border-radius:6px}'+
  '.d{margin-top:28px;font-size:12px;color:#6b6283;border-top:1px solid #ddd;padding-top:12px}button{margin-top:20px;padding:8px 16px;font:inherit;cursor:pointer}@media print{button{display:none}}'+
  '</style></head><body><h1>Cybershield scan report</h1><div class="sub">'+e(r.time)+' · '+e(r.kind)+'</div>'+
  '<div class="v">'+e(r.label)+'</div><div class="s">'+r.score+'% <small>'+e(r.scoreLabel)+'</small></div><div class="m">'+e(r.meta)+'</div>'+
  '<h3>Findings</h3><ul>'+r.notes.map(n=>'<li>'+e(n)+'</li>').join('')+'</ul>'+
  (r.passages?'<h3>Passages that influenced the score</h3><pre>'+e(r.passages)+'</pre>':'')+
  '<div class="d">This is a probabilistic assessment, not proof. Do not use a score alone to accuse anyone or to judge a link safe.</div>'+
  '<button onclick="window.print()">Print / save as PDF</button></body></html>';
}
const reportName=()=>'cybershield-report-'+new Date().toISOString().slice(0,10)+'.html';

$('printBtn').addEventListener('click', () => window.print());
$('saveRep').addEventListener('click', () => {
  if (!lastReport) return;
  const url = URL.createObjectURL(new Blob([buildReport(lastReport)], { type: 'text/html' }));
  const link = document.createElement('a');
  link.href = url; link.download = reportName();
  document.body.appendChild(link); link.click(); link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
});

$('copyResult').addEventListener('click', async () => {
  try {
    await navigator.clipboard.writeText(lastResultText);
    $('copyResult').textContent = 'Copied ✓';
  } catch {
    $('copyResult').textContent = 'Copy failed';
  }
});

// =====================================================================
// DOCUMENT: real analysis via backend
// =====================================================================
const dropzoneDocText = $('dropzoneDocText');
const runDocBtn = $('runDoc');
const loadingDoc = $('loadingDoc');
const errorDoc = $('errorDoc');
const panelDocFrame = $('panel-document');
let extractedText = '';
const docResultCache = new Map();
let fileToken = 0; // guards against a slow earlier file finishing after a newer one

function hashText(str) {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = (Math.imul(31, h) + str.charCodeAt(i)) | 0;
  return String(h) + ':' + str.length;
}

function showDocError(msg) {
  errorDoc.textContent = '⚠ ' + msg;
  errorDoc.classList.add('show');
}

function setDocStatus(name, meta) {
  dropzoneDocText.innerHTML = '';
  const nameEl = document.createElement('div');
  nameEl.className = 'doc-name';
  nameEl.textContent = name;
  const metaEl = document.createElement('div');
  metaEl.className = 'doc-meta';
  metaEl.textContent = meta;
  dropzoneDocText.append(nameEl, metaEl);
}

const decodeXmlEntities = s => s
  .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"')
  .replace(/&apos;/g, "'").replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(+n))
  .replace(/&amp;/g, '&');

async function extractPptxText(buf) {
  if (typeof JSZip === 'undefined') throw new Error('PowerPoint reader failed to load — check your connection and reload.');
  const zip = await JSZip.loadAsync(buf);
  const slideFiles = Object.keys(zip.files)
    .filter(n => /^ppt\/slides\/slide\d+\.xml$/.test(n))
    .sort((a, b) => parseInt(a.match(/slide(\d+)/)[1], 10) - parseInt(b.match(/slide(\d+)/)[1], 10));
  if (!slideFiles.length) throw new Error('No slides found — is this a valid .pptx?');
  let text = '';
  for (const name of slideFiles) {
    const xml = await zip.file(name).async('string');
    // Join text runs within a paragraph, separate paragraphs with newlines
    const paras = xml.match(/<a:p[ >][\s\S]*?<\/a:p>/g) || [];
    const lines = paras.map(p =>
      (p.match(/<a:t[^>]*>([^<]*)<\/a:t>/g) || [])
        .map(m => decodeXmlEntities(m.replace(/<a:t[^>]*>|<\/a:t>/g, ''))).join('')
    ).filter(Boolean);
    text += lines.join('\n') + '\n\n';
  }
  return text.trim();
}

async function extractPdfText(buf) {
  if (typeof pdfjsLib === 'undefined') throw new Error('PDF reader failed to load — check your connection and reload.');
  let pdf;
  try {
    pdf = await pdfjsLib.getDocument({ data: buf }).promise;
  } catch {
    throw new Error('This PDF could not be opened — it may be password-protected or corrupted.');
  }
  let text = '';
  const maxPages = Math.min(pdf.numPages, 40);
  for (let i = 1; i <= maxPages && text.length < MAX_CHARS * 1.5; i++) {
    const page = await pdf.getPage(i);
    const content = await page.getTextContent();
    let line = '';
    for (const item of content.items) {
      line += item.str + (item.hasEOL ? '\n' : ' ');
    }
    text += line + '\n\n';
  }
  text = text.trim();
  if (!text) throw new Error("No selectable text found — this looks like a scanned/image-only PDF, which needs OCR that this tool doesn't do.");
  return text;
}

async function extractDocxText(buf) {
  if (typeof mammoth === 'undefined') throw new Error('Word reader failed to load — check your connection and reload.');
  const result = await mammoth.extractRawText({ arrayBuffer: buf });
  return result.value.trim();
}

function handleDocFile(file) {
  const name = file.name.toLowerCase();
  const myToken = ++fileToken;
  errorDoc.classList.remove('show');
  runDocBtn.disabled = true;
  extractedText = '';
  resultEl.classList.remove('show');

  if (file.size > MAX_FILE_BYTES) {
    setDocStatus(file.name, 'file too large');
    return showDocError(`File is over ${MAX_FILE_BYTES / 1024 / 1024} MB — try a smaller one.`);
  }
  setDocStatus(file.name, 'reading...');

  const reader = new FileReader();
  reader.onload = async e => {
    try {
      let text = '';
      if (name.endsWith('.txt') || name.endsWith('.md')) text = new TextDecoder('utf-8').decode(e.target.result);
      else if (name.endsWith('.docx')) text = await extractDocxText(e.target.result);
      else if (name.endsWith('.pdf')) text = await extractPdfText(e.target.result);
      else if (name.endsWith('.pptx')) text = await extractPptxText(e.target.result);
      else if (name.endsWith('.doc') || name.endsWith('.ppt')) {
        throw new Error("Legacy .doc and .ppt formats aren't supported — save as .docx / .pptx and try again.");
      } else throw new Error('Unsupported file type. Use PDF, DOCX, PPTX or TXT.');

      if (myToken !== fileToken) return; // a newer file replaced this one
      text = text.replace(/\u0000/g, '');
      if (text.length < 50) throw new Error("Couldn't find enough readable text in this file (need at least 50 characters).");

      extractedText = text;
      const words = text.split(/\s+/).filter(Boolean).length;
      let meta = `${words.toLocaleString()} words extracted — ready to scan`;
      if (words < 150) meta += ' · short text gives low-confidence results';
      else if (text.length > MAX_CHARS) meta += ` · first ${MAX_CHARS.toLocaleString()} characters will be analysed`;
      setDocStatus(file.name, meta);
      runDocBtn.disabled = false;
    } catch (err) {
      if (myToken !== fileToken) return;
      console.error(err);
      showDocError(err.message || 'Could not read this file.');
      setDocStatus(file.name, 'extraction failed');
    }
  };
  reader.onerror = () => { showDocError('Could not read this file.'); setDocStatus(file.name, 'read failed'); };
  reader.readAsArrayBuffer(file);
}
wireDropzone($('dropzoneDoc'), $('docInput'), handleDocFile);

function setScanning(frame, loadingEl, btn, on) {
  frame.classList.toggle('scanning', on);
  loadingEl.classList.toggle('show', on);
  btn.disabled = on;
  statusText.textContent = on ? 'SCANNING...' : 'SCANNER READY';
}

runDocBtn.addEventListener('click', async () => {
  if (!extractedText) return;
  resultEl.classList.remove('show');
  errorDoc.classList.remove('show');
  setScanning(panelDocFrame, loadingDoc, runDocBtn, true);

  const words = extractedText.split(/\s+/).filter(Boolean).length;
  const wasTruncated = extractedText.length > MAX_CHARS;
  const text = extractedText.slice(0, MAX_CHARS);
  const key = hashText(text);

  // Same text → same reading, instead of drifting between runs
  if (docResultCache.has(key)) {
    setTimeout(() => {
      const c = docResultCache.get(key);
      showResult(c.score, c.notes, { confidence: c.confidence, truncated: wasTruncated, words, phrases: c.phrases, source: text });
      setScanning(panelDocFrame, loadingDoc, runDocBtn, false);
    }, 400);
    return;
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 50000);
  try {
    const response = await fetch('/api/analyze', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      signal: controller.signal,
      body: JSON.stringify({ text })
    });
    let parsed;
    try { parsed = await response.json(); }
    catch { throw new Error('Got an unreadable response from the server — try again.'); }
    if (response.status === 401) { location.href = '/login.html'; return; }
    if (!response.ok) throw new Error(parsed.error || `Server returned an error (status ${response.status}).`);
    if (typeof parsed.score !== 'number' || !Array.isArray(parsed.notes)) {
      throw new Error('Got an incomplete response from the server — try again.');
    }
    const score = Math.max(0, Math.min(100, Math.round(parsed.score)));
    docResultCache.set(key, { score, notes: parsed.notes, confidence: parsed.confidence, phrases: parsed.phrases });
    showResult(score, parsed.notes, { confidence: parsed.confidence, truncated: parsed.truncated || wasTruncated, words, phrases: parsed.phrases, source: text });
  } catch (err) {
    console.error(err);
    showDocError(err.name === 'AbortError'
      ? 'The analysis took too long and timed out. Try again.'
      : (err.message || 'Something went wrong reaching the analysis service.'));
  } finally {
    clearTimeout(timeout);
    setScanning(panelDocFrame, loadingDoc, runDocBtn, false);
  }
});

// =====================================================================
// IMAGE: real analysis via backend.  VIDEO: clearly-labelled placeholder
// =====================================================================
function setupDemo({ zoneId, inputId, textId, btnId, frameId, loadingId, mimePrefix, render, delay }) {
  const zone = $(zoneId), input = $(inputId), textEl = $(textId), btn = $(btnId);
  const frame = $(frameId), loading = $(loadingId);
  let ready = false;
  let objectUrl = null;

  wireDropzone(zone, input, file => {
    if (!file.type.startsWith(mimePrefix)) return;
    if (objectUrl) URL.revokeObjectURL(objectUrl);
    objectUrl = URL.createObjectURL(file);
    textEl.innerHTML = '';
    const media = render(objectUrl);
    media.className = 'preview';
    textEl.appendChild(media);
    const label = document.createElement('div');
    label.textContent = file.name;
    textEl.appendChild(label);
    ready = true;
    btn.disabled = false;
    resultEl.classList.remove('show');
  });

  btn.addEventListener('click', () => {
    if (!ready) return;
    resultEl.classList.remove('show');
    setScanning(frame, loading, btn, true);
    setTimeout(() => {
      showResult(50, [
        'This is a placeholder: no video analysis was performed.',
        'Video scanning isn’t included in this build. Try the document or image tab for a live analysis.'
      ], { demo: true });
      setScanning(frame, loading, btn, false);
    }, delay);
  });
}

// ---- image scanning ----
const imgBtn = $('runImage'), imgErr = $('errorImage');
let imgPayload = null, imgUrl = null;
const showImgError = m => { imgErr.textContent = '⚠ ' + m; imgErr.classList.add('show'); };

async function prepImage(file) {
  if (/^image\/(jpeg|png|webp)$/.test(file.type) && file.size <= 3 * 1024 * 1024) {
    const b64 = await new Promise((res, rej) => {
      const r = new FileReader();
      r.onload = () => res(String(r.result).split(',')[1]);
      r.onerror = rej;
      r.readAsDataURL(file);
    });
    return { image: b64, mediaType: file.type, downscaled: false };
  }
  // Large files and GIFs: re-encode as a JPEG capped at 1600px
  const bmp = await createImageBitmap(file);
  const s = Math.min(1, 1600 / Math.max(bmp.width, bmp.height));
  const c = document.createElement('canvas');
  c.width = Math.round(bmp.width * s);
  c.height = Math.round(bmp.height * s);
  c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
  return { image: c.toDataURL('image/jpeg', 0.92).split(',')[1], mediaType: 'image/jpeg', downscaled: true };
}

wireDropzone($('dropzone'), $('fileInput'), async file => {
  imgPayload = null;
  imgBtn.disabled = true;
  imgErr.classList.remove('show');
  resultEl.classList.remove('show');
  if (!/^image\/(jpeg|png|webp|gif)$/.test(file.type)) return showImgError('Use a JPG, PNG, WebP or GIF image.');
  if (file.size > 25 * 1024 * 1024) return showImgError('Image is over 25 MB.');
  try {
    imgPayload = await prepImage(file);
    if (imgUrl) URL.revokeObjectURL(imgUrl);
    imgUrl = URL.createObjectURL(file);
    const box = $('dropzoneText');
    box.innerHTML = '';
    const im = document.createElement('img');
    im.className = 'preview'; im.src = imgUrl; im.alt = 'Selected image preview';
    const label = document.createElement('div');
    label.textContent = file.name + (imgPayload.downscaled ? ' · downscaled for analysis' : '');
    box.append(im, label);
    imgBtn.disabled = false;
  } catch {
    imgPayload = null;
    showImgError('Could not read this image.');
  }
});

imgBtn.addEventListener('click', async () => {
  if (!imgPayload) return;
  resultEl.classList.remove('show');
  imgErr.classList.remove('show');
  setScanning($('panel-image'), $('loadingImage'), imgBtn, true);
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 65000);
  try {
    const response = await fetch('/api/analyze-image', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      signal: controller.signal,
      body: JSON.stringify({ image: imgPayload.image, mediaType: imgPayload.mediaType })
    });
    let parsed;
    try { parsed = await response.json(); }
    catch { throw new Error('Got an unreadable response from the server — try again.'); }
    if (response.status === 401) { location.href = '/login.html'; return; }
    if (!response.ok) throw new Error(parsed.error || `Server returned an error (status ${response.status}).`);
    if (typeof parsed.score !== 'number' || !Array.isArray(parsed.notes)) throw new Error('Got an incomplete response from the server — try again.');
    showResult(Math.max(0, Math.min(100, Math.round(parsed.score))), parsed.notes, { confidence: parsed.confidence, kind: 'image' });
  } catch (err) {
    console.error(err);
    showImgError(err.name === 'AbortError' ? 'The analysis took too long and timed out. Try again.' : (err.message || 'Something went wrong.'));
  } finally {
    clearTimeout(timeout);
    setScanning($('panel-image'), $('loadingImage'), imgBtn, false);
  }
});

// ---- link checking ----
const urlInput = $('urlInput'), runLink = $('runLink'), errorLink = $('errorLink');
urlInput.addEventListener('input', () => { runLink.disabled = urlInput.value.trim().length < 4; errorLink.classList.remove('show'); });
urlInput.addEventListener('keydown', e => { if (e.key === 'Enter' && !runLink.disabled) runLink.click(); });
const showLinkError = m => { errorLink.textContent = '⚠ ' + m; errorLink.classList.add('show'); };

runLink.addEventListener('click', async () => {
  resultEl.classList.remove('show');
  errorLink.classList.remove('show');
  setScanning($('panel-link'), $('loadingLink'), runLink, true);
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 70000);
  try {
    const response = await fetch('/api/analyze-url', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      signal: controller.signal,
      body: JSON.stringify({ url: urlInput.value })
    });
    let p;
    try { p = await response.json(); }
    catch { throw new Error('Got an unreadable response from the server — try again.'); }
    if (response.status === 401) { location.href = '/login.html'; return; }
    if (!response.ok) throw new Error(p.error || `Server returned an error (status ${response.status}).`);

    const notes = [];
    if (p.flags.length) notes.push(...p.flags);
    else notes.push('The rule check found no red flags in the link itself.');
    (p.notes || []).forEach(n => notes.push('Second opinion: ' + n));
    if (p.aiUnavailable || p.aiScore === null) notes.push('The AI second opinion was unavailable, so this result is rules only.');
    if (p.safeBrowsing === 'clean') notes.push('Google Safe Browsing: not listed.');
    notes.push('This checks the link text only. The page itself was never opened.');
    showResult(p.score, notes, { confidence: p.confidence, kind: 'url', host: p.host });
  } catch (err) {
    console.error(err);
    showLinkError(err.name === 'AbortError' ? 'The check took too long and timed out. Try again.' : (err.message || 'Something went wrong.'));
  } finally {
    clearTimeout(timeout);
    setScanning($('panel-link'), $('loadingLink'), runLink, false);
    runLink.disabled = urlInput.value.trim().length < 4;
  }
});

setupDemo({
  zoneId: 'dropzoneVideo', inputId: 'videoInput', textId: 'dropzoneVideoText', btnId: 'runVideo',
  frameId: 'panel-video', loadingId: 'loadingVideo', mimePrefix: 'video/', delay: 1200,
  render: url => { const v = document.createElement('video'); v.src = url; v.controls = true; return v; }
});

// ---- accordion ----
const accItems = document.querySelectorAll('.accordion-item');
accItems.forEach(item => {
  const head = item.querySelector('.accordion-head');
  const body = item.querySelector('.accordion-body');
  head.setAttribute('aria-expanded', item.classList.contains('open'));
  if (item.classList.contains('open')) body.style.maxHeight = body.scrollHeight + 'px';
  head.addEventListener('click', () => {
    const isOpen = item.classList.contains('open');
    accItems.forEach(i => {
      i.classList.remove('open');
      i.querySelector('.accordion-body').style.maxHeight = null;
      i.querySelector('.accordion-head').setAttribute('aria-expanded', 'false');
    });
    if (!isOpen) {
      item.classList.add('open');
      body.style.maxHeight = body.scrollHeight + 'px';
      head.setAttribute('aria-expanded', 'true');
    }
  });
});
